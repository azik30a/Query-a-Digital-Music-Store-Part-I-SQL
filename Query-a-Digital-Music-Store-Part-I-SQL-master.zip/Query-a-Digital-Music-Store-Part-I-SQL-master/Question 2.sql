SELECT firstName,lastName,country
 FROM customer
 WHERE country IN("Brazil","Canada","India","Sweden");
